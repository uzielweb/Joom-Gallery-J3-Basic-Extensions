# JoomprettyPhoto
This plugin integrates the prettyPhoto (http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/) popup box into JoomGallery.
