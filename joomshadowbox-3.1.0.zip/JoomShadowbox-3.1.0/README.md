# JoomShadowbox
This plugin integrates Shadowbox into JoomGallery. Please respect the licensing agreement on http://shadowbox-js.com.
