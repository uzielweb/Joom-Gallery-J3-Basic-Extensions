# JoomBu
This plugin displays a button which helps you at inserting images and categories from JoomGallery into your content articles.

You are able to select the images and categories from a popup window, for example.

You will also need the content plugin, so that the images are shown correctly in your articles.
