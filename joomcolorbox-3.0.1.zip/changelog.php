<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-3/Plugins/JoomColorbox/trunk/changelog.php $
// $Id: changelog.php 4096 2013-02-14 11:58:50Z erftralle $
/******************************************************************************\
**   JoomGallery Plugin 'Integrate Colorbox'                                  **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2013 JoomGallery::ProjectTeam                              **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html                            **
\******************************************************************************/

// No direct access
defined('_JEXEC') or die('Restricted access');
?>

CHANGELOG PLG_JOOMCOLORBOX (since Version 3.0 BETA )

Legende / Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

-------------------------------------------------------------------------------
JoomColorBox version: 3.0.1
-------------------------------------------------------------------------------
20190409
^ Change update server
