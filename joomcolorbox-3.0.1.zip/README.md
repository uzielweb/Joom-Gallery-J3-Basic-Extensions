# JoomColorBox
This Plugin integrates the [Colorbox](http://www.jacklmoore.com/colorbox/) as popup box into JoomGallery.
