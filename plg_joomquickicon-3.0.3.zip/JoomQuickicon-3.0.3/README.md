# JoomQuickicon
This plugin displays a JoomGallery icon in the Joomla! control panel.
