# JoomPlu
Content Plugin JoomPlu - Enables the displaying of images and categories from JoomGallery in content.
