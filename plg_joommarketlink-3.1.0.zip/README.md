# JoomMarketLink
This plugin displays an icon near images in the detail view for linking them with market products.
