# JoomFancybox
This plugin integrates fancyBox into JoomGallery. Please respect the licensing agreement on http://fancyapps.com/fancybox/
