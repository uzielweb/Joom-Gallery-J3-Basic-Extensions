# JoomLytebox
This Plugin integrates the Lytebox (http://lytebox.com/) as popup box into JoomGallery.
