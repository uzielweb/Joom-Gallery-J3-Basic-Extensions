# JoomTreeView
The module shows the categories and subcategories of the gallery in the way you know from a explorer showing a filesystem. It gives a quick overview of the total existing categories in the gallery and is ideally suited to quickly and easily navigate between them.
