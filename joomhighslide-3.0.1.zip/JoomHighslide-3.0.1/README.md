# JoomHighslide
This plugin integrates Highslide JS into JoomGallery. Please respect the licensing agreement on http://highslide.com.
