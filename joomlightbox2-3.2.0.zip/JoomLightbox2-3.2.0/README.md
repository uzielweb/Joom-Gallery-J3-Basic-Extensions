# JoomLightbox2
This plugin integrates Lightbox 2 (http://lokeshdhakar.com/projects/lightbox2/) into JoomGallery.
