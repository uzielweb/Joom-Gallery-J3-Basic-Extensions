# JoomStats
This module displays a small gallery statistic.
