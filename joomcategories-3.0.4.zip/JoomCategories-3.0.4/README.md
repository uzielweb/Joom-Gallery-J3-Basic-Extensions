# JoomCategories
The module JoomCategories shows an adjustable number of categories, optionally with manually determined , randomly determined or without a thumbnail.
