# JoomSearchModule
Combined with the search plugin you can provide a search for pictures and/or categories in JoomGallery.
