<?php
defined('_JEXEC') or die('Restricted access');
?>

CHANGELOG plg_search_joomgallery (since Version 3.1.1)

Legende / Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

-------------------------------------------------------------------------------
PLG_SEARCH_JOOMGALLERY version: 3.1.2
-------------------------------------------------------------------------------
20190611
# Removes escaping the search item title in the template override as it may 
  contain HTML tags
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
PLG_SEARCH_JOOMGALLERY version: 3.1.1
-------------------------------------------------------------------------------
20190403
^ Change update server
-------------------------------------------------------------------------------
