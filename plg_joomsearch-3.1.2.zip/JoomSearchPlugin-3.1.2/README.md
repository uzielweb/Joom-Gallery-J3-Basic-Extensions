# JoomSearchPlugin
This plugin extends the standard Joomla! search.
