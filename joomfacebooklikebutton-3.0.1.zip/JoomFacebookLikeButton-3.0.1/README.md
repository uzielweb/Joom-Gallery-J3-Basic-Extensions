# JoomFacebookLikeButton
This plugin displays a Like-Button of Facebook near to the detail images of the gallery.

Please note that the plugin has to be enabled in plugin manager of Joomla! afore (like all other plugins) and that the button will only be displayed in the default detail view of JoomGallery (thus, e.g. not in the popup boxes).

